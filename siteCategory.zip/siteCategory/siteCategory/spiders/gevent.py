import requests
import gevent
from gevent import monkey
monkey.patch_all()
import gevent
import urllib.request



# contents = []
# pool = Pool(20)

# def req(url):
#     res = requests.get(url)
#     contents.append(res.status_code)
# urls = [
#     "http://www.baidu.com",
#     "http://www.iplaysoft.com",
#     "http://www.cupfox.com",
#     "http://www.opbear.com",
#     "http://www.bing.ren"
# ]

# gtasks = [pool.spawn(req, url) for url in urls]
# gevent.joinall(gtasks)
# print(contents)
def run_task(url):
    print('Visit --> %s' % url)
    try:
        response = urllib.request.urlopen(url)
        data = response.read()
        print('%d bytes received from %s.' % (len(data), url))
    except Exception as e:
        print(e)
 
if __name__ == '__main__':
    urls = ['https://www.baidu.com','https://docs.python.org/3/library/urllib.html','https://www.cnblogs.com/wangmo/p/7784867.html']
    greenlets = [gevent.spawn(run_task, url) for url in urls]
    gevent.joinall(greenlets)
