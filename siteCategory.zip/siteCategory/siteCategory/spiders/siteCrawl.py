# -*- coding: utf-8 -*-
import scrapy
from urllib.parse import urlparse 
import requests
from bs4 import BeautifulSoup
import time
import datetime
import os
class SitecrawlSpider(scrapy.Spider):
    name = 'siteCrawl'
    allowed_domains = ['baidu.com']
    count=0
    basePath="../datas/"
    today=str(datetime.date.today())
    #start_urls = ['http://baidu.com/']
    def start_requests(self):
        # #从文件读取IP
        # for line in open("ips.txt"):
        #     ipStr=(line.replace("\n",""))
        #     self.ipStrList.append(ipStr)
        #     self.q.put(ipStr)
        #url=https://www.baidu.com/s?wd=title: ( (体育| 运动))&pn=50&oq=title: ( (体育| 运动))&tn=baiduadv&rn=50&ie=utf-8&usm=1&rsv_pq=f424409b00009a5f&rsv_t=d521L7Fw/24NNbBmAMiIetrQCiQtRNZe0vk8URA4WEwiXTu9oKzldHz3PTJNs74
        # #url1=self.url+self.ipStrList[self.offset]
        # self.ip=self.q.get()
        #catetory=['购物','体育','运动','成人','财经','金融','证券','博彩','作弊', '交通','新闻', '政府', '旅游','出行', '赌博', 'P2P下载资源', '反动言论', '艺术', '视频', '博客', '游戏', '聊天','论坛', '彩票', '文学', '电影', '化工','能源', '凶杀','暴力', '电子','电工', '动漫','卡通', '公司', '星座','相术', '环保','绿化', '汽车', '政府', '邮箱', '法律法规', '教育','培训', '冶金','矿产', '服饰', '医药医疗', '财经证券', '电子商务', '饮食','文化', '烟草网站', '家具','装潢', '农林','牧渔', '追星', '学校','高校','大学', '学院','招聘', '网络科技', '少儿', '搜索引擎', '军事', '软件之家', '宠物', '广告', '图片摄影', '手机通信', '门户网站', '地方信息', '房屋', '科学','技术', '宗教', '婚恋','交友']
        catetory=['台湾省','广东省','江苏省','浙江省','山东省','福建省','辽宁省','黑龙江省','河北省','湖北省','湖南省','安徽省','吉林省','海南省','四川省','陕西省','山西省','河南省','新疆','江西省','广西','内蒙古','云南省','甘肃省','宁夏','青海省','贵州省','西藏','北京','上海','天津','重庆','香港','澳门']
        #catetory=['成人','运动', '作弊', '交通', '中国成人', '旅游','出行', '新闻','政府','大学','赌博', 'P2P下载资源', '反动言论', '艺术', '视频', '博客', '游戏', '聊天','论坛', '彩票', '文学', '电影', '化工','能源', '凶杀','暴力', '电子电工', '动漫卡通', '公司', '星座','相术', '环保','绿化', '汽车', '政府', '邮箱', '法律法规', '教育培训', '冶金矿产', '时尚服饰', '医药医疗', '财经证券', '电子商务', '饮食文化', '烟草网站', '家具装潢', '农林牧渔', '追星', '学校网站', '人才招聘', '网络科技', '少儿', '搜索引擎', '军事', '软件之家', '宠物空间', '广告', '图片摄影', '手机通信', '门户网站', '地方信息', '房屋买卖', '科学技术', '宗教信仰', '婚恋','交友']
        for keywords in catetory:
        	keywords=keywords
        	print(keywords)
        	for n in range(1,17):
        	    #url="https://www.baidu.com/s?wd=title:"+keywords+"&pn="+str((n-1)*10)+"&oq=title:"+keywords+"&ie=utf-8&usm=3&rsv_idx=1&rsv_pq=a14ccc610002a25d&rsv_t=a802A%2BRpCjw4ZpMmFzmzZJxynjIVmVkhMw3TADUz3DoGEmYjOSoWoLF5jjs"
        	    url="https://www.baidu.com/s?wd=title:"+keywords+"&pn="+str((n-1)*50)+"&oq=title:"+keywords+"&tn=baiduadv&rn=50&ie=utf-8&usm=1&rsv_pq=e5103e060002ca29&rsv_t=3d15cvgRmjEUfXVaAN70HTuC/XtG7eEldD5TZ89LTL8f0jvcABy/7c0FkMumomA"
        	    yield scrapy.Request(url=url,callback=self.parse)
    def parse(self, response):
        for each in response.xpath("//div[@class='f13']/a[1]"):
        	datas =each.xpath("string(.)").extract()[0]
        	datas=datas.replace('...','')
        	#print(datas+'11111111111')
        	if datas[0:4]=='http':
        		print(datas+'--------')
        		xieyi=(datas.split('//')[-2]).split(':')[-2]
        		#print(xieyi+'xiey')
        		if xieyi=='https' or xieyi=='http':
        			print(datas+'::')
        			domain=urlparse(datas)
        			domain=domain.netloc
        			print(domain)
        	else:
        		#print(11111111111)
        		domain=datas.split('/')[0]
        		print(domain)
        	try:
        		url='http://'+domain
        		res = requests.get(url,timeout=0.5)
        		
        		classlist=['成人','体育','运动', '财经','购物','金融','证券','博彩','作弊', '交通','新闻', '政府', '旅游','出行', '赌博', 'P2P下载资源', '反动言论', '艺术', '视频', '博客', '游戏', '聊天','论坛', '彩票', '文学', '电影', '化工','能源', '凶杀','暴力', '电子','电工', '动漫','卡通', '公司', '星座','相术', '环保','绿化', '汽车', '政府', '邮箱', '法律法规', '教育','培训', '冶金','矿产', '服饰', '医药医疗', '财经证券', '电子商务', '饮食','文化', '烟草网站', '家具','装潢', '农林','牧渔', '追星', '学校','高校','大学', '学院','招聘', '网络科技', '少儿', '搜索引擎', '军事', '软件之家', '宠物', '广告', '图片摄影', '手机通信', '门户网站', '地方信息', '房屋', '科学','技术', '宗教', '婚恋','交友']
        		soup = BeautifulSoup(res.text, 'lxml')
        		site_title=soup.title.text
        		#print(site_title)
        		for keyword in classlist:

        			if keyword in site_title:
        				FullPath = self.basePath+keyword   
        				if not os.path.exists(FullPath):
        					os.makedirs(FullPath)
        				#site_txt=("title:"+site_title+" site:"+url+" category："+keyword)
        				site_txt=url.split('//')[-1]
        				print(site_txt)
        				fileName=self.basePath+keyword+'/'+self.today+'.txt'
        				print(fileName)

        				with open(fileName,'a+')as f:
        					f.write(site_txt+'\n')
        				self.count+=1
        				print(self.count)
        	except Exception as e:
        		print(e)
#       if each.xpath("/pre/text()")!=[]:
