import json
import jsonpath
import re
import requests

cms=["5kcrm", "74CMS", "AMCMS", "appcms", "aspcms"]
s="Red Hat PolicyKit  安全漏洞 "
for value in cms:
    if s.find(value) == -1:
        tag=0
        print("No 'is' here!")
       
    else:
        print(s)
        tag=1
        print("Found: "+value+" in the string.")
        break

if tag==1:
	print(22222)
else:
	print(11111111)
