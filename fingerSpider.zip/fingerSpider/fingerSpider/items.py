# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class FingerspiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    CMS=scrapy.Field()
    framwork=scrapy.Field()
    language=scrapy.Field()
    web_server=scrapy.Field()
    os_server=scrapy.Field()
    other=scrapy.Field()
    url=scrapy.Field()

