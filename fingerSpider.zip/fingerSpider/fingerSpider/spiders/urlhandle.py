import json
url=[]
for line in open('finger.json','r',encoding='utf-8'):
	dic=json.loads(line)
	print(type(dic))
	print(dic)
	if 'framwork' in dic:

		if dic['framwork']=='ThinkPHP':
			print(dic['url'])
			url.append(dic['url'])
for url in url:

	with open('thinkphp.txt','a+')as f:
		f.write(url+'\n')

