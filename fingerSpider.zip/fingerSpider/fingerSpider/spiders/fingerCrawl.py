# -*- coding: utf-8 -*-
import scrapy
import json
import jsonpath
from fingerSpider.items import FingerspiderItem
class FingercrawlSpider(scrapy.Spider):
	name = 'fingerCrawl'
	allowed_domains = ['bugscaner.com']
	start_urls = ['http://bugscaner.com/']
	headers={
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
	}

	count=0
	def start_requests(self):

		for domain in open('data2.txt','r'):
			url=domain
			print(domain)
			post={'hash':'0eca8914342fc63f5a2ef5246b7a3b14_7289fd8cf7f420f594ac165e475f1479','url':url}
			yield scrapy.FormRequest(url='http://whatweb.bugscaner.com/what/',method="POST",headers=self.headers,formdata =post,callback=self.parse)
	def keyCheck(self,dic,key):
		if key in dic:
			value=jsonpath.jsonpath(dic,"$.."+key)
			for value in value:
				if isinstance(value,list)==True:
					for value in value:
						value=value
				else:
					value=value
		else:
			value=''
		return value
	def parse(self, response):
		item=FingerspiderItem()
		dic=json.loads(response.body)
		try:
			txtfinger=dic
			if txtfinger['url']=='':
				pass
			else:
				if txtfinger['error']=='5':
					pass 
				else:

					print(txtfinger)
					item['url']=self.keyCheck(txtfinger,'url')
					item['CMS']=self.keyCheck(txtfinger,'CMS')
					item['framwork']=self.keyCheck(txtfinger,'Web Frameworks')
					item['web_server']=self.keyCheck(txtfinger,'Web Servers')
					item['os_server']=self.keyCheck(txtfinger,'Operating Systems')
					item['language']=self.keyCheck(txtfinger,'Programming Languages')
					item['other']=self.keyCheck(txtfinger,'JavaScript Frameworks')
					with open('webfinger.txt','a+')as f:
						f.write(str(txtfinger)+'\n')
			#time.sleep(3)
			yield item
			self.count+=1
			print(self.count)
		except Exception as e:
			print(e)
