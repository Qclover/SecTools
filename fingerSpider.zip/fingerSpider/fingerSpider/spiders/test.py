import jsonpath

data={'Web Frameworks': ['Twitter Bootstrap'], 'Programming Languages': ['PHP'], 'url': 'blog.trustnote.org', 'JavaScript Frameworks': ['jQuery'], 'Web Servers': ['Nginx 1.10.3'], 'Font Scripts': ['Font Awesome', 'Google Font API'], 'error': 'no', 'CMS': ['WordPress'], 'Operating Systems': ['Ubuntu']}
if "Web Frameworks" in data:
	txt=jsonpath.jsonpath(data,"$..Web Frameworks")
else:
	txt="123"
print(txt)